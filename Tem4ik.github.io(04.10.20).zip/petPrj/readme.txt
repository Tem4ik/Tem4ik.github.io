Here is will be navigate meet board with some 'pet projects' 4 fun
here will be used only native JS, CSS, HTML tech without any ready lib's


HTML doc -> define root structure of DOMobj;
JS doc -> declares classes, functions, event's; main app logic determined here.
CSS -> define behaviour styles of element's , their animation parammeter's;